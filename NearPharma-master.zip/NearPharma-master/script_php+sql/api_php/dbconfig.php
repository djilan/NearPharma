<?php
	//***********@uthor Basile PAZIMNA*****************//	
class Settings{
    const host="localhost"; 
    const db = "db_pharma";
    const username="basile";
    const password="linio123479";
    const port="5432";
}

